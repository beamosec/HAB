The fritzing breadboard images are drawn in Fritzing software. You may go to their official website to download the latest version. 

http://fritzing.org/download/

The code is for Arduino. You can download Arduino IDE at https://www.arduino.cc/en/Main/Software. 
If you have questions for the code, you can refer this website https://www.arduino.cc/en/Reference/HomePage. 